package me.timp.privatemine;

public class PartnerMine {
}
