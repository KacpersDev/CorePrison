package me.timp.privatemine;

public class FamousMine {
}
